package data

import "embed"

// Files provides unicode data source files.
//
//go:embed *
var Files embed.FS
