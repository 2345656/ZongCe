# shaping

This text shaping library is shared by multiple Go UI toolkits including Fyne, and GIO.
